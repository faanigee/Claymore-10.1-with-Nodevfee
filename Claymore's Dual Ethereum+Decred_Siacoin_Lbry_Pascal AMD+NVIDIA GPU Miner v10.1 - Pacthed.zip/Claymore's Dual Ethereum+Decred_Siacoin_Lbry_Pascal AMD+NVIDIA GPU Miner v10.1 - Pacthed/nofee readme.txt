Just place your wallet address into start.bat and start mining at full speed without devfee.
dont use exchage wallet for mining...!!!
use your personal wallet for mining...!!!
you can mine any fork of ethereum like exp, ubiq, pirl etc...
(devfee of fork is mined at ethereum or ethereum classic you can get it using myetherwallet.com) from your fork address...!!!
enjoy free mining...!!!

consider for donation...!!!
ETH or ETC: 0x61cc1a74b6d0480bd8559b1954718e2400a34ba8